import React, { createContext, useState, useContext, useEffect } from "react";

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [cartCount, setCartCount] = useState(0);
  const [isCounting, setIsCounting] = useState(false);

  const addToCart = (item) => {
    // Always treat each item as unique – no merging
    setCartItems((prev) => [...prev, item]);
    setCartCount((prev) => prev + item.quantity || 1);
    setIsCounting(true);
  };

  const updateQuantity = (index, newQty) => {
    const updated = [...cartItems];
    if (newQty <= 0) {
      updated.splice(index, 1);
    } else {
      updated[index].quantity = newQty;
    }
    setCartItems(updated);
    setCartCount(updated.reduce((sum, item) => sum + item.quantity, 0));
  };

  const removeFromCart = (index) => {
    const removedItem = cartItems[index];
    const updated = [...cartItems];
    updated.splice(index, 1);
    setCartItems(updated);
    setCartCount((prev) => prev - (removedItem?.quantity || 1));
  };

  useEffect(() => {
    if (isCounting) {
      const timer = setTimeout(() => setIsCounting(false), 500);
      return () => clearTimeout(timer);
    }
  }, [isCounting]);

  return (
    <CartContext.Provider
      value={{
        cartItems,
        cartCount,
        isCounting,
        addToCart,
        updateQuantity,
        removeFromCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export { CartContext };
