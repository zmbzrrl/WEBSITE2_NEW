// src/assets/iconLibrary.js

const images = import.meta.glob("./icons/*.png", { eager: true });

const icons = Object.entries(images).reduce((acc, [path, module]) => {
  const name = path.split("/").pop().replace(".png", "");
  acc[name] = module.default;
  return acc;
}, {});

export default icons;
