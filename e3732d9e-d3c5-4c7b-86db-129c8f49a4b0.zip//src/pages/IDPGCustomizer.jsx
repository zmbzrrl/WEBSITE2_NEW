import React, { useContext, useState } from "react";
import { CartContext } from "../contexts/CartContext";
import "./Customizer.css";
import CartButton from "../components/CartButton";
import { useNavigate } from "react-router-dom";

const iconOptions = [
  { id: "ac", label: "❄️ AC" },
  { id: "fan", label: "🌀 Fan" },
  { id: "light", label: "💡 Light" },
  { id: "tv", label: "📺 TV" },
];

const GridCell = ({ index, onClick, children }) => (
  <div
    onClick={() => onClick(index)}
    style={{
      width: "30%",
      height: "70px",
      display: "inline-block",
      textAlign: "center",
      background: "transparent",
      margin: "5px",
      position: "relative",
      boxSizing: "border-box",
      verticalAlign: "top",
    }}
  >
    {children}
  </div>
);

function IDPGCustomizer() {
  const { addToCart } = useContext(CartContext);
  const [selectedIcon, setSelectedIcon] = useState(null);
  const [placedIcons, setPlacedIcons] = useState([]);
  const [iconTexts, setIconTexts] = useState({});
  const navigate = useNavigate();

  const handlePlaceIcon = (cellIndex) => {
    const isOccupied = placedIcons.some((icon) => icon.position === cellIndex);
    if (isOccupied || selectedIcon === null) return;

    const iconPosition = {
      id: Date.now(),
      iconId: selectedIcon.id,
      label: selectedIcon.label,
      position: cellIndex,
    };

    setPlacedIcons((prev) => [...prev, iconPosition]);
    setSelectedIcon(null);
  };

  const handleIconClick = (icon) => {
    setSelectedIcon(icon);
  };

  const handleTextChange = (e, cellIndex) => {
    const newText = e.target.value;
    setIconTexts((prev) => ({
      ...prev,
      [cellIndex]: newText,
    }));
  };

  const handleDeleteIcon = (id) => {
    setPlacedIcons((prev) => prev.filter((icon) => icon.id !== id));
  };

  const handleAddToCart = () => {
    const design = {
      type: "IDPG",
      icons: Array.from({ length: 11 })
        .map((_, index) => {
          const icon = placedIcons.find((i) => i.position === index);
          return {
            iconId: icon?.iconId || null,
            label: icon?.label || "",
            position: index,
            text: iconTexts[index] || "",
          };
        })
        .filter((entry) => entry.iconId || entry.text),
      quantity: 1,
    };
    addToCart(design);
  };

  return (
    <div className="customizer-container">
      <div style={{ position: "absolute", top: 20, right: 30 }}>
        <CartButton />
      </div>

      <h2>Customize your Corridor Panel</h2>

      <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
        {iconOptions.map((icon) => (
          <div
            key={icon.id}
            onClick={() => handleIconClick(icon)}
            style={{
              padding: "10px",
              background: "#e0e0e0",
              borderRadius: "8px",
              cursor: "pointer",
            }}
          >
            {icon.label}
          </div>
        ))}
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "20px",
          background: "#f0f0f0",
          padding: "10px",
          border: "2px solid #ccc",
          width: "fit-content",
        }}
      >
        {/* Large Icons Grid */}
        <div>
          <div style={{ display: "flex", flexDirection: "row", gap: "10px" }}>
            {Array.from({ length: 1 }).map((_, i) => {
              const index = 9 + i;
              const icon = placedIcons.find((i) => i.position === index);
              const text = iconTexts[index];

              return (
                <div
                  key={index}
                  onClick={() => handlePlaceIcon(index)}
                  style={{
                    width: "450px",
                    height: "200px",
                    backgroundColor: "#ffffff",
                    position: "relative",
                    border: "1px solid #999",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      justifyContent: "center",
                      height: "100%",
                      position: "relative",
                    }}
                  >
                    {icon && (
                      <div style={{ fontSize: "48px", fontWeight: "bold" }}>
                        {icon.label}
                      </div>
                    )}
                    {text && (
                      <div style={{ fontSize: "100px", marginTop: "5px" }}>
                        {text}
                      </div>
                    )}
                    {icon && (
                      <button
                        onClick={() => handleDeleteIcon(icon.id)}
                        style={{
                          position: "absolute",
                          top: "-5px",
                          right: "-5px",
                          width: "20px",
                          height: "20px",
                          borderRadius: "50%",
                          backgroundColor: "red",
                          color: "white",
                          fontSize: "14px",
                          border: "none",
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          padding: 0,
                        }}
                      >
                        −
                      </button>
                    )}
                  </div>
                  <input
                    type="text"
                    value={iconTexts[index] || ""}
                    onChange={(e) => handleTextChange(e, index)}
                    placeholder="Add text"
                    style={{
                      position: "absolute",
                      bottom: "5px",
                      left: "5px",
                      width: "90%",
                      fontSize: "12px",
                      textAlign: "center",
                    }}
                  />
                </div>
              );
            })}
          </div>
        </div>
        {/* Small Icons Grid */}
        <div>
          <div style={{ display: "flex", flexWrap: "wrap", width: "300px" }}>
            {Array.from({ length: 9 }).map((_, index) => (
              <GridCell key={index} index={index} onClick={handlePlaceIcon}>
                {(() => {
                  const icon = placedIcons.find((i) => i.position === index);
                  const text = iconTexts[index];
                  return (
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                        position: "relative",
                        height: "50%",
                      }}
                    >
                      {icon && (
                        <div style={{ fontSize: "24px" }}>{icon.label}</div>
                      )}
                      {text && (
                        <div style={{ fontSize: "17px", marginTop: "5px" }}>
                          {text}
                        </div>
                      )}
                      {icon && (
                        <button
                          onClick={() => handleDeleteIcon(icon.id)}
                          style={{
                            position: "absolute",
                            top: "-5px",
                            right: "-5px",
                            width: "20px",
                            height: "20px",
                            borderRadius: "50%",
                            backgroundColor: "red",
                            color: "white",
                            fontSize: "14px",
                            border: "none",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            padding: 0,
                          }}
                        >
                          −
                        </button>
                      )}
                    </div>
                  );
                })()}
                <input
                  type="text"
                  value={iconTexts[index] || ""}
                  onChange={(e) => handleTextChange(e, index)}
                  placeholder="Add text"
                  style={{
                    position: "absolute",
                    bottom: "5px",
                    left: "80px",
                    width: "90%",
                    fontSize: "12px",
                    textAlign: "center",
                  }}
                />
              </GridCell>
            ))}
          </div>
        </div>
      </div>
      {/* Navigation buttons */}
      <div
        style={{
          marginTop: 20,
          display: "flex",
          gap: "10px",
          justifyContent: "center",
        }}
      >
        <button onClick={() => navigate("/")} style={{ padding: "10px 15px" }}>
          Back to Panel Selection
        </button>
        <button
          onClick={() => navigate("/subtypes/IDPG")}
          style={{ padding: "10px 15px" }}
        >
          Back to Corridor Panels
        </button>
        <button
          onClick={handleAddToCart}
          style={{
            padding: "10px 15px",
            backgroundColor: "#4CAF50",
            color: "white",
            border: "none",
            cursor: "pointer",
          }}
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}
export default IDPGCustomizer;
