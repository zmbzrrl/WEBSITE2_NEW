import React, { useContext, useState } from "react";
import { CartContext } from "../contexts/CartContext";
import { useNavigate } from "react-router-dom";
import CartButton from "../components/CartButton";

const iconOptions = [
  { id: "ac", label: "❄️ AC" },
  { id: "fan", label: "🌀 Fan" },
  { id: "pir", label: "⭘ PIR", displayLabel: "⭘" },
];

const GridCell = ({ index, onClick, isDisabled, children }) => (
  <div
    onClick={() => {
      if (!isDisabled) onClick(index);
    }}
    style={{
      width: "30%",
      height: "100px",
      display: "inline-block",
      textAlign: "center",
      background: "transparent",
      margin: "5px",
      position: "relative",
      boxSizing: "border-box",
      verticalAlign: "top",
      cursor: isDisabled ? "default" : "pointer",
    }}
  >
    {children}
  </div>
);

function TAGCustomizer() {
  const { addToCart } = useContext(CartContext);
  const navigate = useNavigate();

  const [selectedIcon, setSelectedIcon] = useState(null);
  const [placedIcons, setPlacedIcons] = useState([]);
  const [iconTexts, setIconTexts] = useState({});
  const [swapped, setSwapped] = useState(false);

  const fixedFanCells = [3, 4, 5];

  const handlePlaceIcon = (cellIndex) => {
    if (fixedFanCells.includes(cellIndex)) return;

    if (selectedIcon?.id === "pir") {
      if (![4, 7].includes(cellIndex)) return;
      const pirExists = placedIcons.some((icon) => icon.iconId === "pir");
      if (pirExists) return;
    }

    const isOccupied = placedIcons.some((icon) => icon.position === cellIndex);
    if (isOccupied || selectedIcon === null) return;

    const iconPosition = {
      id: Date.now(),
      iconId: selectedIcon.id,
      label: selectedIcon.displayLabel || selectedIcon.label,
      position: cellIndex,
    };

    setPlacedIcons((prev) => [...prev, iconPosition]);
    setSelectedIcon(null);
  };

  const handleIconClick = (icon) => setSelectedIcon(icon);

  const handleTextChange = (e, cellIndex) => {
    const newText = e.target.value;
    setIconTexts((prev) => ({
      ...prev,
      [cellIndex]: newText,
    }));
  };

  const handleDeleteIcon = (id) => {
    setPlacedIcons((prev) => prev.filter((icon) => icon.id !== id));
  };
  const handleAddToCart = () => {
    const fanIcons = fixedFanCells.map((pos) => ({
      iconId: "fan",
      label: "🌀",
      position: pos,
      text: "",
    }));

    const customIcons = Array.from({ length: 9 }).map((_, rawIndex) => {
      const index = getDisplayedIndex(rawIndex);
      const icon = placedIcons.find((i) => i.position === index);
      return {
        iconId: icon?.iconId || null,
        label: icon?.label || "",
        position: index,
        text: iconTexts[index] || "",
      };
    });

    // Remove empty rows
    const icons = [...fanIcons, ...customIcons].filter(
      (entry) => entry.iconId || entry.text
    );

    const design = {
      type: "tag",
      swapped,
      icons,
      quantity: 1,
    };

    addToCart(design);
  };

  const getDisplayedIndex = (i) => {
    if (!swapped) return i;
    if (i >= 3 && i <= 5) return i + 3;
    if (i >= 6 && i <= 8) return i - 3;
    return i;
  };

  return (
    <div style={{ padding: "40px", textAlign: "center", position: "relative" }}>
      <div style={{ position: "absolute", top: 20, right: 30 }}>
        <CartButton />
      </div>
      <h2>Customize your Thermostat</h2>
      <div
        style={{
          display: "flex",
          gap: "10px",
          marginBottom: "20px",
          justifyContent: "center",
        }}
      >
        {iconOptions.map((icon) => (
          <div
            key={icon.id}
            onClick={() => handleIconClick(icon)}
            style={{
              padding: "10px",
              background: "#e0e0e0",
              borderRadius: "8px",
              cursor: "pointer",
            }}
          >
            {icon.label}
          </div>
        ))}
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            width: "350px",
            height: "350px",
            background: "#f0f0f0",
            position: "relative",
            border: "2px solid #ccc",
            margin: "auto",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: "15px",
              left: "50%",
              transform: "translateX(-50%)",
              fontWeight: "bold",
              fontSize: "20px",
            }}
          >
            °C/°F
          </div>

          {Array.from({ length: 9 }).map((_, rawIndex) => {
            const index = getDisplayedIndex(rawIndex);
            const isFanRow = fixedFanCells.includes(index);
            const icon = placedIcons.find((i) => i.position === index);

            return (
              <GridCell
                key={rawIndex}
                index={index}
                onClick={handlePlaceIcon}
                isDisabled={isFanRow}
              >
                {(() => {
                  if (index === 0)
                    return (
                      <div style={{ fontSize: "40px", marginTop: "50px" }}>
                        −
                      </div>
                    );

                  if (index === 1)
                    return (
                      <div style={{ fontSize: "30px", marginTop: "55px" }}>
                        23°C
                      </div>
                    );

                  if (index === 2)
                    return (
                      <div style={{ fontSize: "40px", marginTop: "50px" }}>
                        +
                      </div>
                    );

                  if (isFanRow) {
                    const fanStyles = {
                      3: { fontSize: "30px", marginTop: "27px" },
                      4: { fontSize: "40px", marginTop: "20px" },
                      5: { fontSize: "50px", marginTop: "13px" },
                    };
                    const style = fanStyles[index] || {
                      fontSize: "40px",
                      marginTop: "20px",
                    };

                    return <div style={style}>🌀</div>;
                  }

                  if ([6, 7, 8, 4].includes(index)) {
                    return (
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          height: "100%",
                          position: "relative",
                          fontSize: "35px",
                        }}
                      >
                        {icon?.label}
                        {icon && !fixedFanCells.includes(index) && (
                          <button
                            onClick={() => handleDeleteIcon(icon.id)}
                            style={{
                              position: "absolute",
                              top: "-5px",
                              right: "-5px",
                              width: "20px",
                              height: "20px",
                              borderRadius: "50%",
                              backgroundColor: "red",
                              color: "white",
                              fontSize: "14px",
                              border: "none",
                              cursor: "pointer",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              padding: 0,
                            }}
                          >
                            ×
                          </button>
                        )}
                      </div>
                    );
                  }

                  return null;
                })()}
              </GridCell>
            );
          })}
        </div>

        <button
          onClick={() => setSwapped(!swapped)}
          title="Swap Rows 2 and 3"
          style={{
            marginLeft: "20px",
            width: "40px",
            height: "40px",
            borderRadius: "50%",
            backgroundColor: "#4CAF50",
            color: "white",
            fontSize: "20px",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          ↕
        </button>
      </div>

      <div style={{ marginTop: 20 }}>
        <button onClick={() => navigate("/")}>Back to Panel Selection</button>
        <button
          onClick={handleAddToCart}
          style={{ marginLeft: 10, cursor: "pointer" }}
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}

export default TAGCustomizer;
