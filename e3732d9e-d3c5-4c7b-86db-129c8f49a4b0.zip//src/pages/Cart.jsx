import { useContext } from "react";
import { CartContext } from "../contexts/CartContext";
import { useNavigate } from "react-router-dom";
import CartButton from "../components/CartButton";

function Cart() {
  const { cartItems, updateQuantity, removeFromCart } = useContext(CartContext);
  const navigate = useNavigate();

  const renderSPPanel = (item) => (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: "5px",
        width: "350px",
        margin: "20px auto",
        background: "#f0f0f0",
        padding: "10px",
        border: "2px solid #ccc",
      }}
    >
      {Array.from({ length: 9 }).map((_, index) => {
        const icon = item.icons.find((i) => i.position === index);
        return (
          <div
            key={index}
            style={{
              minHeight: "80px",
              border: "0px solid #ddd",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "20px",
            }}
          >
            {icon?.label}
            {icon?.text && (
              <div style={{ fontSize: "14px", marginTop: "4px" }}>
                {icon.text}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
  const renderTAGPanel = (item) => (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: "5px",
        width: "350px",
        margin: "20px auto",
        background: "#f0f0f0",
        padding: "10px",
        border: "2px solid #ccc",
      }}
    >
      {Array.from({ length: 9 }).map((_, index) => {
        const icon = item.icons.find((i) => i.position === index);
        return (
          <div
            key={index}
            style={{
              minHeight: "80px",
              border: "0px solid #ddd",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "20px",
            }}
          >
            {icon?.label}
            {icon?.text && (
              <div style={{ fontSize: "14px", marginTop: "4px" }}>
                {icon.text}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );

  const renderDPHPanel = (item) => (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(6, 1fr)",
        gap: "5px",
        width: "90%",
        maxWidth: "600px",
        margin: "20px auto",
        background: "#f0f0f0",
        padding: "10px",
        border: "2px solid #ccc",
      }}
    >
      {Array.from({ length: 18 }).map((_, index) => {
        const icon = item.icons.find((i) => i.position === index);
        return (
          <div
            key={index}
            style={{
              minHeight: "80px",
              border: "0px solid #ddd",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "20px",
            }}
          >
            {icon?.label}
            {icon?.text && (
              <div style={{ fontSize: "14px", marginTop: "4px" }}>
                {icon.text}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );

  const renderDPVPanel = (item) => (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: "5px",
        width: "95%",
        maxWidth: "350px",
        margin: "20px auto",
        background: "#f0f0f0",
        padding: "10px",
        border: "2px solid #ccc",
        borderRadius: "8px",
      }}
    >
      {Array.from({ length: 18 }).flatMap((_, index) => {
        const icon = item.icons.find((i) => i.position === index);
        const cell = (
          <div
            key={index}
            style={{
              minHeight: "80px",
              border: "0px solid #ddd",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "20px",
              backgroundColor: "#f0f0f0",
              borderRadius: "4px",
            }}
          >
            {icon?.label}
            {icon?.text && (
              <div style={{ fontSize: "14px", marginTop: "5px" }}>
                {icon.text}
              </div>
            )}
          </div>
        );

        if (index === 9) {
          return [
            <div
              key="spacer"
              style={{
                gridColumn: "1 / -1",
                height: "40px",
              }}
            />,
            cell,
          ];
        }

        return cell;
      })}
    </div>
  );

  const renderX2VPanel = (item) => (
    <div
      style={{
        margin: "20px auto",
        width: "350px",
        background: "#f0f0f0",
        border: "2px solid #ccc",
        padding: "10px",
        borderRadius: "8px",
      }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "5px",
          marginBottom: "10px",
        }}
      >
        {Array.from({ length: 9 }).map((_, index) => {
          const icon = item.icons.find((i) => i.position === index);
          return (
            <div
              key={index}
              style={{
                minHeight: "100px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "20px",
                backgroundColor: "transparent",
                borderRadius: "4px",
              }}
            >
              {icon?.label}
              {icon?.text && (
                <div style={{ fontSize: "12px", marginTop: "4px" }}>
                  {icon.text}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(1, 1fr)",
          gap: "5px",
        }}
      >
        {Array.from({ length: 2 }).map((_, index) => {
          const positionIndex = 9 + index;
          const icon = item.icons.find((i) => i.position === positionIndex);
          return (
            <div
              key={positionIndex}
              style={{
                minHeight: "100px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "30px",
                backgroundColor: "transparent",
                borderRadius: "4px",
              }}
            >
              {icon?.label}
              {icon?.text && (
                <div style={{ fontSize: "14px", marginTop: "4px" }}>
                  {icon.text}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderX2HPanel = (item) => (
    <div
      style={{
        margin: "20px auto",
        width: "fit-content",
        background: "#f0f0f0",
        border: "2px solid #ccc",
        padding: "10px",
        borderRadius: "8px",
        display: "flex",
        gap: "20px",
      }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "5px",
        }}
      >
        {Array.from({ length: 9 }).map((_, index) => {
          const icon = item.icons.find((i) => i.position === index);
          return (
            <div
              key={index}
              style={{
                minHeight: "100px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "20px",
                backgroundColor: "transparent",
                borderRadius: "4px",
                width: "100px",
              }}
            >
              {icon?.label}
              {icon?.text && (
                <div style={{ fontSize: "12px", marginTop: "4px" }}>
                  {icon.text}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "10px",
        }}
      >
        {Array.from({ length: 2 }).map((_, index) => {
          const positionIndex = 9 + index;
          const icon = item.icons.find((i) => i.position === positionIndex);
          return (
            <div
              key={positionIndex}
              style={{
                width: "150px",
                height: "250px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "30px",
                borderRadius: "4px",
              }}
            >
              {icon?.label}
              {icon?.text && (
                <div style={{ fontSize: "14px", marginTop: "5px" }}>
                  {icon.text}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  // ✅ New renderX1HPanel added here
  const renderX1HPanel = (item) => (
    <div
      style={{
        margin: "20px auto",
        width: "fit-content",
        background: "#f0f0f0",
        border: "2px solid #ccc",
        padding: "10px",
        borderRadius: "8px",
      }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "5px",
        }}
      >
        {Array.from({ length: 9 }).map((_, index) => {
          const icon = item.icons.find((i) => i.position === index);
          return (
            <div
              key={index}
              style={{
                minHeight: "100px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "20px",
                backgroundColor: "transparent",
                borderRadius: "4px",
                width: "100px",
              }}
            >
              {icon?.label}
              {icon?.text && (
                <div style={{ fontSize: "12px", marginTop: "4px" }}>
                  {icon.text}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderPanelGrid = (item) => {
    switch (item.type) {
      case "sp":
        return renderSPPanel(item);
      case "tag":
        return renderTAGPanel(item);
      case "DPH":
        return renderDPHPanel(item);
      case "DPV":
        return renderDPVPanel(item);
      case "X2V":
        return renderX2VPanel(item);
      case "X2H":
        return renderX2HPanel(item);
      case "X1H":
        return renderX1HPanel(item);
      default:
        return null;
    }
  };

  return (
    <div style={{ padding: "40px", textAlign: "center", position: "relative" }}>
      <div style={{ position: "absolute", top: 20, right: 30 }}>
        <CartButton />
      </div>

      <h2>Your Cart</h2>

      {cartItems.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        cartItems.map((item, index) => (
          <div
            key={index}
            style={{
              borderBottom: "1px solid #ccc",
              margin: "20px auto",
              maxWidth: "600px",
              paddingBottom: "20px",
            }}
          >
            <p>
              <strong>{item.type}</strong>
              {" - Quantity: "}
              <button
                onClick={() => updateQuantity(index, item.quantity - 1)}
                disabled={item.quantity <= 1}
              >
                {" - "}
              </button>
              {item.quantity}
              <button onClick={() => updateQuantity(index, item.quantity + 1)}>
                {" + "}
              </button>
            </p>

            {renderPanelGrid(item)}
            <button onClick={() => removeFromCart(index)}>Remove</button>
          </div>
        ))
      )}

      <button onClick={() => navigate("/")}>Back to Panel Selection</button>
    </div>
  );
}

export default Cart;
