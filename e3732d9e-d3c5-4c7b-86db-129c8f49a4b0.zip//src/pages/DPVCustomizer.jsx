import React, { useContext, useState } from "react";
import { CartContext } from "../contexts/CartContext";
import "./Customizer.css";
import CartButton from "../components/CartButton";
import { useNavigate } from "react-router-dom";

const iconOptions = [
  { id: "ac", label: "❄️ AC" },
  { id: "fan", label: "🌀 Fan" },
  { id: "light", label: "💡 Light" },
  { id: "tv", label: "📺 TV" },
];

const GridCell = ({ index, onClick, children }) => (
  <div
    onClick={() => onClick(index)}
    style={{
      width: "140%",
      height: "100px",
      display: "inline-block",
      textAlign: "center",
      background: "transparent",
      margin: "10px",
      position: "relative",
      boxSizing: "content-box",
      verticalAlign: "10%",
    }}
  >
    {children}
  </div>
);

function DPVCustomizer() {
  const { addToCart } = useContext(CartContext);
  const [selectedIcon, setSelectedIcon] = useState(null);
  const [placedIcons, setPlacedIcons] = useState([]);
  const [iconTexts, setIconTexts] = useState({});
  const navigate = useNavigate();

  const rows = 6;
  const columns = 3;

  const handlePlaceIcon = (cellIndex) => {
    const isOccupied = placedIcons.some((icon) => icon.position === cellIndex);
    if (isOccupied || selectedIcon === null) return;

    const iconPosition = {
      id: Date.now(),
      iconId: selectedIcon.id,
      label: selectedIcon.label,
      position: cellIndex,
    };

    setPlacedIcons((prev) => [...prev, iconPosition]);
    setSelectedIcon(null);
  };

  const handleIconClick = (icon) => {
    setSelectedIcon(icon);
  };

  const handleTextChange = (e, cellIndex) => {
    const newText = e.target.value;
    setIconTexts((prev) => ({
      ...prev,
      [cellIndex]: newText,
    }));
  };

  const handleDeleteIcon = (id) => {
    setPlacedIcons((prev) => prev.filter((icon) => icon.id !== id));
  };

  const handleAddToCart = () => {
    const design = {
      type: "DPV",
      rows,
      columns,
      icons: Array.from({ length: columns * rows })
        .map((_, index) => {
          const icon = placedIcons.find((i) => i.position === index);
          return {
            iconId: icon?.iconId || null,
            label: icon?.label || "",
            position: index,
            text: iconTexts[index] || "",
          };
        })
        .filter((entry) => entry.iconId || entry.text),
      quantity: 1,
    };
    addToCart(design);
  };

  return (
    <div className="customizer-container">
      <div style={{ position: "absolute", top: 20, right: 30 }}>
        <CartButton />
      </div>

      <h2>Customize your Double Panel</h2>

      <div style={{ display: "flex", gap: "10px", marginBottom: "10px" }}>
        {iconOptions.map((icon) => (
          <div
            key={icon.id}
            onClick={() => handleIconClick(icon)}
            style={{
              padding: "10px",
              background: "#e0e0e0",
              borderRadius: "8px",
              cursor: "pointer",
            }}
          >
            {icon.label}
          </div>
        ))}
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          width: "500px",
          background: "#f0f0f0",
          position: "relative",
          border: "2px solid #ccc",
          margin: "10 auto",
        }}
      >
        {Array.from({ length: rows }).map((_, rowIdx) => (
          <div
            key={`row-${rowIdx}`}
            style={{
              display: "flex",
              justifyContent: "center",
              marginBottom: rowIdx === 2 ? "40px" : "0", // <-- add extra space after row 3
            }}
          >
            {Array.from({ length: columns }).map((_, colIdx) => {
              const index = rowIdx * columns + colIdx;
              const icon = placedIcons.find((i) => i.position === index);
              const text = iconTexts[index];

              return (
                <React.Fragment key={index}>
                  {colIdx === 3 && <div style={{ width: "20px" }} />}
                  <GridCell index={index} onClick={handlePlaceIcon}>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                        position: "relative",
                        height: "80%",
                      }}
                    >
                      {icon && (
                        <div style={{ fontSize: "24px" }}>{icon.label}</div>
                      )}
                      {text && (
                        <div style={{ fontSize: "20px", marginTop: "5px" }}>
                          {text}
                        </div>
                      )}
                      {icon && (
                        <button
                          onClick={() => handleDeleteIcon(icon.id)}
                          style={{
                            position: "absolute",
                            top: "-5px",
                            right: "-5px",
                            width: "20px",
                            height: "20px",
                            borderRadius: "50%",
                            backgroundColor: "red",
                            color: "white",
                            fontSize: "14px",
                            border: "none",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            padding: 0,
                          }}
                        >
                          −
                        </button>
                      )}
                    </div>

                    <input
                      type="text"
                      value={iconTexts[index] || ""}
                      onChange={(e) => handleTextChange(e, index)}
                      placeholder="Add text"
                      style={{
                        position: "absolute",
                        bottom: "5px",
                        left: "3px",
                        width: "90%",
                        fontSize: "12px",
                        textAlign: "center",
                      }}
                    />
                  </GridCell>
                </React.Fragment>
              );
            })}
          </div>
        ))}
      </div>

      <div
        style={{
          marginTop: 20,
          display: "flex",
          gap: "10px",
          justifyContent: "center",
        }}
      >
        <button onClick={() => navigate("/")} style={{ padding: "10px 15px" }}>
          Back to Panel Selection
        </button>
        <button
          onClick={() => navigate("/subtypes/double")}
          style={{ padding: "10px 15px" }}
        >
          Back to Double Panels
        </button>
        <button
          onClick={handleAddToCart}
          style={{
            padding: "10px 15px",
            backgroundColor: "#4CAF50",
            color: "white",
            border: "none",
            cursor: "pointer",
          }}
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}

export default DPVCustomizer;
