// Import necessary libraries and components
import React, { useContext, useState } from "react";
import { CartContext } from "../contexts/CartContext"; // Cart state management
import { useNavigate } from "react-router-dom"; // For page navigation
import CartButton from "../components/CartButton"; // The cart icon button
import icons from "../assets/iconLibrary"; // Dynamically loaded icons

// Convert icon map into array of options
const iconOptions = Object.keys(icons).map((key) => ({
  id: key,
  label: <img src={icons[key]} alt={key} style={{ width: 24, height: 24 }} />,
}));

// Component for each grid cell
const GridCell = ({ index, onClick, children }) => (
  <div
    onClick={() => onClick(index)} // Calls parent function when clicked
    style={{
      width: "30%", // Each cell is roughly 1/3 of the width
      height: "100px",
      display: "inline-block",
      textAlign: "center",
      background: "transparent",
      margin: "5px",
      position: "relative",
      boxSizing: "border-box",
      verticalAlign: "top",
    }}
  >
    {children}
  </div>
);

function SPCustomizer() {
  // Access the cart context and navigation
  const { addToCart } = useContext(CartContext);
  const navigate = useNavigate();

  // State to track selected icon
  const [selectedIcon, setSelectedIcon] = useState(null);

  // State to track icons placed in the grid
  const [placedIcons, setPlacedIcons] = useState([]);

  // State for custom text under icons (per cell)
  const [iconTexts, setIconTexts] = useState({});

  // Handle placing an icon into a grid cell
  const handlePlaceIcon = (cellIndex) => {
    const isOccupied = placedIcons.some((icon) => icon.position === cellIndex); // Prevent overwrite
    if (isOccupied || selectedIcon === null) return;

    const iconPosition = {
      id: Date.now(), // Unique ID
      iconId: selectedIcon.id,
      label: selectedIcon.label,
      image: selectedIcon.image,
      position: cellIndex,
    };

    setPlacedIcons((prev) => [...prev, iconPosition]);
    setSelectedIcon(null); // Reset selection
  };

  // Handle selecting an icon from the options
  const handleIconClick = (icon) => {
    setSelectedIcon(icon);
  };

  // Handle text change input under an icon
  const handleTextChange = (e, cellIndex) => {
    const newText = e.target.value;
    setIconTexts((prev) => ({
      ...prev,
      [cellIndex]: newText,
    }));
  };

  // Remove an icon from a grid cell
  const handleDeleteIcon = (id) => {
    setPlacedIcons((prev) => prev.filter((icon) => icon.id !== id));
  };

  // When user clicks "Add to Cart"
  const handleAddToCart = () => {
    const design = {
      type: "sp", // Updated panel type
      icons: Array.from({ length: 9 }) // Generate array of 9 cells
        .map((_, index) => {
          const icon = placedIcons.find((i) => i.position === index);
          return {
            iconId: icon?.iconId || null,
            label: icon?.label || "",
            position: index,
            text: iconTexts[index] || "",
          };
        })
        .filter((entry) => entry.iconId || entry.text), // Only keep filled cells

      quantity: 1, // Default quantity
    };

    addToCart(design); // Save to cart context
  };

  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      {/* Cart Button in the top right */}
      <div style={{ position: "absolute", top: 20, right: 30 }}>
        <CartButton />
      </div>
      {/* Page heading */}
      <h2>Customize your SP Panel</h2> {/* Updated heading */}
      {/* Icon selection buttons */}
      <div
        style={{
          display: "flex",
          gap: "10px",
          marginBottom: "20px",
          justifyContent: "center",
          flexWrap: "wrap",
        }}
      >
        {iconOptions.map((icon) => (
          <div
            key={icon.id}
            onClick={() => handleIconClick(icon)}
            style={{
              padding: "10px",
              background: "#e0e0e0",
              borderRadius: "8px",
              cursor: "pointer",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              width: "60px",
            }}
          >
            <img
              src={icon.image}
              alt={icon.label}
              style={{ width: "30px", height: "30px", marginBottom: "5px" }}
            />
            <span style={{ fontSize: "12px" }}>{icon.label}</span>
          </div>
        ))}
      </div>
      {/* Grid container */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          width: "350px",
          height: "350px",
          background: "#f0f0f0",
          position: "relative",
          border: "2px solid #ccc",
          margin: "auto",
        }}
      >
        {/* Render 9 grid cells for SP panel */}
        {Array.from({ length: 9 }).map((_, index) => (
          <GridCell key={index} index={index} onClick={handlePlaceIcon}>
            {(() => {
              const icon = placedIcons.find((i) => i.position === index);
              const text = iconTexts[index];

              return (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    position: "relative",
                    height: "100%",
                  }}
                >
                  {/* Show icon image */}
                  {icon && (
                    <img
                      src={icon.image}
                      alt={icon.label}
                      style={{ width: "30px", height: "30px" }}
                    />
                  )}
                  {/* Show text */}
                  {text && (
                    <div style={{ fontSize: "12px", marginTop: "5px" }}>
                      {text}
                    </div>
                  )}
                  {/* Delete icon button */}
                  {icon && (
                    <button
                      onClick={() => handleDeleteIcon(icon.id)}
                      style={{
                        position: "absolute",
                        top: "-5px",
                        right: "-5px",
                        width: "20px",
                        height: "20px",
                        borderRadius: "50%",
                        backgroundColor: "red",
                        color: "white",
                        fontSize: "14px",
                        border: "none",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: 0,
                      }}
                    >
                      −
                    </button>
                  )}
                </div>
              );
            })()}
            {/* Text input under the icon */}
            <input
              type="text"
              value={iconTexts[index] || ""}
              onChange={(e) => handleTextChange(e, index)}
              placeholder="Add text"
              style={{
                position: "absolute",
                bottom: "5px",
                left: "5px",
                width: "90%",
                fontSize: "12px",
                textAlign: "center",
              }}
            />
          </GridCell>
        ))}
      </div>
      {/* Navigation buttons */}
      <div style={{ marginTop: 20 }}>
        <button onClick={() => navigate("/")}>Back to Panel Selection</button>
        <button
          onClick={handleAddToCart}
          style={{ marginLeft: 10, cursor: "pointer" }}
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}

export default SPCustomizer;
